# PraiThan v1.0 Clean Vercel Project

Brand: PraiThan  
Tagline: Print The Story  
Domain: praithanprints.com  
Production model: Owner prints and ships from Mesquite, Texas.

## Deploy

1. Download this ZIP.
2. Extract it.
3. In Vercel, create a new project.
4. Upload/import the entire extracted folder.
5. Vercel should detect Next.js.
6. Deploy.

## GoDaddy DNS for Vercel

Root domain:
- Type: A
- Name: @
- Value: 76.76.21.21

WWW:
- Type: CNAME
- Name: www
- Value: cname.vercel-dns.com

Do not delete email/Microsoft records for support@praithanprints.com.

## Security included in this starter

- Security headers in next.config.mjs
- No card data storage
- No unsafe external scripts
- Prepared for Stripe/PayPal hosted checkout
- Prepared for secure backend file upload later

## Future production items

- Supabase database
- Admin login with MFA
- Stripe checkout
- PayPal checkout
- Product image uploads
- Customer artwork uploads
- Order status tracking
- Shipping label/tracking workflow
