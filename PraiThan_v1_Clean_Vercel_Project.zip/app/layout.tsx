import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PraiThan Prints | Print The Story",
  description: "Custom shirts, mugs, caps, tumblers, gifts, utensils, and branded merchandise printed by PraiThan.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
