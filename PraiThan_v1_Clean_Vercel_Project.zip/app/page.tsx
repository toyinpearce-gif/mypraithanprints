"use client";

import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";

type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  description: string;
  tag: string;
  art: string;
};

const products: Product[] = [
  { id: 1, name: "Signature Custom T-Shirt", category: "Shirts", price: 28.99, description: "Premium custom shirt for family, faith, business, and event designs.", tag: "Best Seller", art: "shirt" },
  { id: 2, name: "Personalized Ceramic Mug", category: "Mugs", price: 16.99, description: "Bright printed mugs for photos, names, messages, and gift ideas.", tag: "Gift Ready", art: "mug" },
  { id: 3, name: "Custom Printed Cap", category: "Caps", price: 24.99, description: "Stylish caps with your brand, phrase, logo, or personal message.", tag: "New", art: "cap" },
  { id: 4, name: "Printed Tumbler Cup", category: "Tumblers", price: 32.5, description: "Insulated tumblers with wraparound custom designs.", tag: "Popular", art: "tumbler" },
  { id: 5, name: "Kitchen Utensil Gift Set", category: "Utensils", price: 39.99, description: "Personalized kitchen gifts for homes, weddings, and special occasions.", tag: "Home Favorite", art: "utensils" },
  { id: 6, name: "Business Branding Bundle", category: "Bundles", price: 119.99, description: "Coordinated shirts, caps, mugs, and branded merchandise for businesses.", tag: "For Teams", art: "bundle" }
];

const categories = ["All", "Shirts", "Mugs", "Caps", "Tumblers", "Utensils", "Bundles"];

function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white shadow-sm ring-2 ring-emerald-700/20">
        <svg viewBox="0 0 160 160" className="h-12 w-12" aria-hidden="true">
          <path d="M23 90c8-41 31-61 57-61s49 20 57 61" fill="none" stroke="#04783b" strokeWidth="7" strokeLinecap="round" />
          <path d="M18 113c31-11 93-11 124 0" fill="none" stroke="#04783b" strokeWidth="7" strokeLinecap="round" />
          <circle cx="80" cy="57" r="10" fill="#07110d" />
          <path d="M66 72c6-9 22-9 28 0v37H66V72Z" fill="#07110d" />
          <path d="M69 106h10v30H69zM82 106h10v30H82z" fill="#07110d" />
          <path d="M66 79 45 99M94 79l21 20" stroke="#07110d" strokeWidth="8" strokeLinecap="round" />
          <circle cx="41" cy="92" r="7" fill="#07110d" />
          <path d="M31 103c5-7 15-7 20 0v24H31v-24Z" fill="#07110d" />
          <path d="M34 126h6v18h-6zM43 126h6v18h-6z" fill="#07110d" />
          <circle cx="119" cy="92" r="7" fill="#07110d" />
          <circle cx="113" cy="88" r="4" fill="#07110d" />
          <circle cx="125" cy="88" r="4" fill="#07110d" />
          <path d="M106 127h26l-13-28-13 28Z" fill="#07110d" />
        </svg>
      </div>
      <div>
        <p className="text-2xl font-black tracking-tight">Prai<span className="text-emerald-700">Than</span></p>
        <p className="-mt-1 text-xs font-bold uppercase tracking-[0.22em] text-emerald-700">Print The Story</p>
      </div>
    </div>
  );
}

function Icon({ name }: { name: string }) {
  const icons: Record<string, string> = {
    cart: "M2 2h3l3 13h10l3-8H6 M8 21h.01 M19 21h.01",
    truck: "M10 17H5a2 2 0 0 1-2-2V5h11v12 M14 8h4l3 4v3a2 2 0 0 1-2 2h-1 M7 17h.01 M16 17h.01",
    upload: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M17 8l-5-5-5 5 M12 3v12",
    card: "M2 5h20v14H2z M2 10h20",
    check: "M20 6L9 17l-5-5",
    search: "M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16z M21 21l-4.35-4.35"
  };
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d={icons[name] || icons.check} />
    </svg>
  );
}

function ProductArt({ type }: { type: string }) {
  return (
    <div className="product-art relative flex h-40 items-center justify-center overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-50 via-white to-green-50">
      <div className="absolute -left-8 top-4 h-24 w-24 rounded-full bg-emerald-200 blur-2xl" />
      <div className="absolute -right-8 bottom-4 h-24 w-24 rounded-full bg-green-200 blur-2xl" />
      {type === "shirt" && <div className="relative h-28 w-28 rounded-b-3xl bg-gradient-to-br from-slate-950 to-emerald-700 shadow-xl before:absolute before:-left-7 before:top-5 before:h-11 before:w-9 before:-rotate-12 before:rounded-xl before:bg-emerald-800 after:absolute after:-right-7 after:top-5 after:h-11 after:w-9 after:rotate-12 after:rounded-xl after:bg-emerald-800"><div className="absolute left-1/2 top-8 h-12 w-12 -translate-x-1/2 rounded-full border-4 border-emerald-300" /></div>}
      {type === "mug" && <div className="relative h-24 w-24 rounded-3xl bg-white shadow-xl ring-4 ring-emerald-100 after:absolute after:-right-8 after:top-7 after:h-12 after:w-10 after:rounded-r-full after:border-8 after:border-white"><div className="absolute inset-5 rounded-2xl bg-emerald-700" /></div>}
      {type === "cap" && <div className="relative h-20 w-36 rounded-t-full bg-gradient-to-br from-slate-950 to-emerald-700 shadow-xl after:absolute after:-right-7 after:bottom-0 after:h-7 after:w-16 after:rounded-full after:bg-slate-900"><div className="absolute left-1/2 top-9 h-7 w-14 -translate-x-1/2 rounded-full border-2 border-emerald-300" /></div>}
      {type === "tumbler" && <div className="h-32 w-16 rounded-[2rem] bg-gradient-to-br from-slate-950 via-emerald-700 to-green-400 shadow-xl" />}
      {type === "utensils" && <div className="flex gap-3"><div className="h-32 w-5 rounded-full bg-amber-700" /><div className="h-32 w-5 rounded-full bg-slate-950" /><div className="h-32 w-5 rounded-full bg-emerald-700" /></div>}
      {type === "bundle" && <div className="grid grid-cols-2 gap-3"><div className="h-14 w-20 rounded-2xl bg-emerald-700" /><div className="h-14 w-20 rounded-full bg-slate-950" /><div className="h-14 w-20 rounded-2xl bg-white shadow" /><div className="h-14 w-20 rounded-2xl bg-green-400" /></div>}
    </div>
  );
}

export default function HomePage() {
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState<Product[]>([]);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesCategory = category === "All" || p.category === category;
      const matchesText = `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesText;
    });
  }, [category, query]);

  return (
    <main className="min-h-screen">
      <div className="bg-emerald-800 px-4 py-2 text-sm font-bold text-white">
        <div className="mx-auto flex max-w-7xl justify-between">
          <span>Free shipping on orders over $75</span>
          <span className="hidden sm:inline">Support: support@praithanprints.com</span>
        </div>
      </div>

      <header className="sticky top-0 z-50 border-b border-emerald-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          <Logo />
          <nav className="hidden gap-8 text-sm font-bold lg:flex">
            <a href="#shop" className="hover:text-emerald-700">Shop</a>
            <a href="#custom" className="hover:text-emerald-700">Custom Order</a>
            <a href="#tracking" className="hover:text-emerald-700">Track Order</a>
            <a href="#admin" className="hover:text-emerald-700">Admin Preview</a>
          </nav>
          <button className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-bold text-white">
            Cart ({cart.length})
          </button>
        </div>
      </header>

      <section className="relative overflow-hidden bg-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(22,163,74,.16),transparent_30%),linear-gradient(90deg,#ffffff_0%,#f8fafc_50%,#ecfdf5_100%)]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24">
          <div>
            <p className="inline-flex rounded-full border border-emerald-100 bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-800">PraiThan • Print The Story</p>
            <h1 className="mt-6 text-4xl font-black leading-tight tracking-tight sm:text-5xl">
              Custom prints made with quality, creativity, and meaning.
            </h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-slate-700">
              Custom shirts, mugs, caps, tumblers, gifts, utensils, and branded merchandise made with quality, designed for you, and printed to tell your unique story.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#shop" className="rounded-2xl bg-emerald-700 px-7 py-4 text-center font-bold text-white hover:bg-emerald-800">Shop Collection</a>
              <a href="#custom" className="rounded-2xl border border-emerald-700 px-7 py-4 text-center font-bold text-emerald-800 hover:bg-emerald-50">Create Custom Order</a>
            </div>
          </div>

          <motion.div className="rounded-[2.5rem] bg-white p-4 shadow-2xl ring-1 ring-emerald-100 floating">
            <div className="grid grid-cols-2 gap-4">
              <ProductArt type="shirt" />
              <ProductArt type="mug" />
              <ProductArt type="cap" />
              <ProductArt type="tumbler" />
            </div>
          </motion.div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-4 px-4 py-12 sm:px-6 md:grid-cols-4 lg:px-8">
        {[
          ["check", "High Quality Prints", "Made to last and made to love."],
          ["upload", "Custom Designs", "Upload your idea, logo, or photo."],
          ["truck", "Garage Production", "Printed and shipped from Mesquite, Texas."],
          ["card", "Secure Checkout", "Prepared for Stripe and PayPal."]
        ].map(([icon, title, text]) => (
          <div key={title} className="rounded-3xl bg-white p-6 shadow-sm">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700"><Icon name={icon} /></div>
            <h3 className="font-black">{title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-600">{text}</p>
          </div>
        ))}
      </section>

      <section id="shop" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div>
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-700">Shop by Category</p>
            <h2 className="mt-3 text-3xl font-black tracking-tight">Find the perfect custom product for every moment.</h2>
          </div>
          <div className="relative w-full lg:max-w-sm">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"><Icon name="search" /></span>
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products..." className="w-full rounded-2xl border bg-white py-3 pl-12 pr-4 shadow-sm outline-none focus:ring-4 focus:ring-emerald-100" />
          </div>
        </div>

        <div className="mt-8 flex gap-3 overflow-x-auto pb-2">
          {categories.map((c) => (
            <button key={c} onClick={() => setCategory(c)} className={`rounded-2xl px-5 py-3 text-sm font-bold ${category === c ? "bg-emerald-700 text-white" : "bg-white text-slate-700 shadow-sm hover:bg-emerald-50"}`}>
              {c}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <div key={p.id} className="product-card overflow-hidden rounded-[2rem] bg-white p-3 shadow-sm transition hover:-translate-y-1 hover:shadow-2xl">
              <ProductArt type={p.art} />
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700">{p.tag}</span>
                  <strong>${p.price.toFixed(2)}</strong>
                </div>
                <h3 className="mt-4 text-lg font-black">{p.name}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-600">{p.description}</p>
                <button onClick={() => setCart([...cart, p])} className="mt-5 w-full rounded-2xl bg-emerald-700 px-5 py-3 font-bold text-white hover:bg-slate-950">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="custom" className="bg-slate-950 py-20 text-white">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div>
            <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">Custom Orders</p>
            <h2 className="mt-3 text-3xl font-black">Customers can send their own design ideas.</h2>
            <p className="mt-5 text-slate-300">Customers can request family shirts, business branding, birthday gifts, event bundles, photo mugs, and other custom sublimation orders.</p>
          </div>
          <form className="grid gap-4 rounded-[2rem] bg-white p-6 text-slate-950">
            <input placeholder="Full name" className="rounded-2xl border px-4 py-3" />
            <input placeholder="Email address" className="rounded-2xl border px-4 py-3" />
            <select className="rounded-2xl border px-4 py-3">{categories.filter(c => c !== "All").map(c => <option key={c}>{c}</option>)}</select>
            <div className="rounded-3xl border-2 border-dashed bg-slate-50 p-6 text-center">
              <strong>Upload artwork/photo/logo</strong>
              <p className="text-sm text-slate-500">Live file upload will be added with secure backend storage.</p>
            </div>
            <textarea placeholder="Describe your custom order..." className="min-h-28 rounded-2xl border px-4 py-3" />
            <button type="button" className="rounded-2xl bg-emerald-700 px-5 py-4 font-bold text-white">Submit Custom Request</button>
          </form>
        </div>
      </section>

      <section id="tracking" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-black">Track your order</h2>
        <p className="mt-3 max-w-2xl text-slate-600">Customers can enter their order number to view production and shipment updates. You will update tracking manually from the admin dashboard.</p>
        <div className="mt-6 flex max-w-xl gap-3">
          <input placeholder="Example: PT-1046" className="flex-1 rounded-2xl border px-4 py-3" />
          <button className="rounded-2xl bg-slate-950 px-6 py-3 font-bold text-white">Track</button>
        </div>
      </section>

      <section id="admin" className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-700">Owner Admin Preview</p>
          <h2 className="mt-3 text-3xl font-black">Manage products, orders, production, and shipping.</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-4">
            {["Upload Products", "View Orders", "Update Production", "Add Tracking"].map(item => (
              <div key={item} className="rounded-3xl bg-slate-50 p-6 font-black shadow-sm">{item}</div>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-slate-950 px-4 py-12 text-white">
        <div className="mx-auto max-w-7xl">
          <Logo />
          <p className="mt-5 max-w-xl text-slate-300">PraiThan — Print The Story. Custom sublimation products printed and shipped from Mesquite, Texas.</p>
        </div>
      </footer>
    </main>
  );
}
